void
__assert(const char *error, const char *file, int line)
{
  while (1);
}

